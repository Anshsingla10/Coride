export default function PageLoader(){
    return(
        <div className="flex ">
            <p>Loading....</p>
        </div>
    )
}