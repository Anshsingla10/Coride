-- AlterTable
ALTER TABLE "User" ALTER COLUMN "accountStatus" SET DEFAULT 'banned';
