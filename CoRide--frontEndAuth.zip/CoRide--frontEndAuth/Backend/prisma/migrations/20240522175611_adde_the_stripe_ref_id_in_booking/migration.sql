-- AlterTable
ALTER TABLE "Booking" ADD COLUMN     "stripe_ref_id" TEXT;
