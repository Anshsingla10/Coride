-- AlterTable
ALTER TABLE "Booking" ALTER COLUMN "driverId" SET DEFAULT 1;
