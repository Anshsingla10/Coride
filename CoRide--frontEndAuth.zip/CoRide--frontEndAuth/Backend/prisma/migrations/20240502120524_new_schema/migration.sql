-- AlterTable
ALTER TABLE "User" ALTER COLUMN "address" DROP NOT NULL;
