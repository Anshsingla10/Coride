-- AlterTable
ALTER TABLE "Vehicle" ALTER COLUMN "vehicleOwnerUserId" DROP DEFAULT;
