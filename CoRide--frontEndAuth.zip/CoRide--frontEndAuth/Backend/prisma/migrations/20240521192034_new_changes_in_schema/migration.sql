-- AlterTable
ALTER TABLE "Booking" ADD COLUMN     "seatsRequired" INTEGER NOT NULL DEFAULT 1;
